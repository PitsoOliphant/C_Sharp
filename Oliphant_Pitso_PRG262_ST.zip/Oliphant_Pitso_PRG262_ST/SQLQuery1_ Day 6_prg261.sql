USE MyDB
CREATE TABLE StudentData
 (StudentID int,
 LastName varchar(255),
 FirstName varchar(255),
 Age int

 )
 SELECT* FROM StudentData
 INSERT INTO StudentData(StudentID, LastName, FirstName,Age)
 VALUES(576083, 'Kolokoto','Titi',58),
 (576084, 'Oliphant','pitso',41),
 (576085, 'zuma', 'msholozi',65),
 (576086,'mvala','lerato', 20),
 (576087, 'matseke','Bontle',16)

 SELECT*FROM StudentData
 WHERE StudentID = 576084

 DELETE FROM StudentData
 WHERE FirstName= 'msholozi';

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp2
{
    public partial class NetCareHospital : Form
    {
        Patient cholera = new Patient();
        DataHandler handler = new DataHandler();
        public NetCareHospital()
        {
            InitializeComponent();
        }

        private void btnRegisterPatient_Click(object sender, EventArgs e)
        {
            cholera.PatientID = int.Parse(txtPatientID.Text);
            cholera.PatientName = txtPatientName.Text;
            cholera.PatientSurname = txtPatientSurame.Text;
            cholera.Phone = txtPhone.Text;
            cholera.Age = Convert.ToInt16(txtAge.Text);
            handler.Register(cholera.PatientID, cholera.PatientName, cholera.PatientSurname, cholera.Age, cholera.Phone);
        }

        private void btnSearchPatient_Click(object sender, EventArgs e)
        {
            Searchfrm s = new Searchfrm();
            s.Show();
        }

        private void btnUpdateDetails_Click(object sender, EventArgs e)
        {
            cholera.PatientID = int.Parse(txtPatientID.Text);
            cholera.PatientName = txtPatientName.Text;
            cholera.PatientSurname = txtPatientSurame.Text;
            cholera.Age = Convert.ToInt16(txtAge.Text);
            cholera.Phone = txtPhone.Text;

            handler.Update(int.Parse(txtPatientID.Text), txtPatientName.Text, txtPatientSurame.Text, int.Parse(txtAge.Text), txtPhone.Text);
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            cholera.PatientID = int.Parse(txtPatientID.Text);
            handler.Delete(cholera.PatientID);
        }
    }
}

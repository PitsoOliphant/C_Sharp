﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;
namespace WindowsFormsApp2
{
    class DataHandler
    {
        string connect = @"Data Source=.;Initial Catalog=PatientDB;Integrated Security=True; ";
        SqlConnection conn;
        SqlCommand com;
        SqlDataAdapter adapter;

        public void Register(int Pnr,string Pn,string Ps,int a,string P)
        {
            string query = $"INSERT INTO Patients VALUES('{Pnr}','{Pn}','{Ps}','{a}','{P}')";
            conn = new SqlConnection(connect);
            com = new SqlCommand(query, conn);
            conn.Open();
            try
            {
                com.ExecuteNonQuery();
                MessageBox.Show("Details saved!");
            }
            catch (Exception ea)
            {

                MessageBox.Show("Details not saved! "+ea.Message);
            }
        }

        public DataTable  Search(int Pnr)
        {
            string query = $"SELECT* FROM Patients WHERE [PatientID]='{Pnr}'";
            conn = new SqlConnection(connect);
            com = new SqlCommand(query, conn);
            adapter = new SqlDataAdapter(com);
            DataTable tbl = new DataTable();
            adapter.Fill(tbl);
            return tbl;
        }

        public void Update(int pi,string Pn, string Ps, int a, string P)
        {
            string query = $"UPDATE Patients SET [Name]='{Pn}' ,[Surname]='{Ps}',[Age]='{a}',[Phone]='{P}' WHERE [PatientID]='{pi}'";
            conn = new SqlConnection(connect);
            com = new SqlCommand(query, conn);
            conn.Open();
            try
            {
                com.ExecuteNonQuery();
                MessageBox.Show("Updated entry");
            }
            catch (Exception we)
            {

                MessageBox.Show("Not updated "+we.Message);
            }
        }

        public void Delete(int pid)
        {
            string query=$"DELETE  Patients WHERE [PatientID]='{pid}'"; 
            conn = new SqlConnection(connect);
            com = new SqlCommand(query, conn);
            conn.Open();
            try
            {
                com.ExecuteNonQuery();
                MessageBox.Show("Entry deleted!");
            }
            catch (Exception ex)
            {

                MessageBox.Show("Entry not deleted! "+ex.Message);
            }
        }

    }
}

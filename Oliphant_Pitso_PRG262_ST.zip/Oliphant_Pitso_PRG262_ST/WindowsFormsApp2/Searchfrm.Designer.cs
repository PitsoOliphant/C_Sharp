﻿namespace WindowsFormsApp2
{
    partial class Searchfrm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.txtPatientID_Search = new System.Windows.Forms.TextBox();
            this.btnEnter = new System.Windows.Forms.Button();
            this.dgvSearcContents = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.dgvSearcContents)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(65, 171);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(57, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Patient ID:";
            // 
            // txtPatientID_Search
            // 
            this.txtPatientID_Search.Location = new System.Drawing.Point(128, 171);
            this.txtPatientID_Search.Name = "txtPatientID_Search";
            this.txtPatientID_Search.Size = new System.Drawing.Size(100, 20);
            this.txtPatientID_Search.TabIndex = 1;
            // 
            // btnEnter
            // 
            this.btnEnter.Location = new System.Drawing.Point(128, 249);
            this.btnEnter.Name = "btnEnter";
            this.btnEnter.Size = new System.Drawing.Size(75, 23);
            this.btnEnter.TabIndex = 2;
            this.btnEnter.Text = "Enter";
            this.btnEnter.UseVisualStyleBackColor = true;
            this.btnEnter.Click += new System.EventHandler(this.btnEnter_Click);
            // 
            // dgvSearcContents
            // 
            this.dgvSearcContents.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvSearcContents.Location = new System.Drawing.Point(300, 122);
            this.dgvSearcContents.Name = "dgvSearcContents";
            this.dgvSearcContents.Size = new System.Drawing.Size(240, 150);
            this.dgvSearcContents.TabIndex = 3;
            // 
            // Searchfrm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.dgvSearcContents);
            this.Controls.Add(this.btnEnter);
            this.Controls.Add(this.txtPatientID_Search);
            this.Controls.Add(this.label1);
            this.Name = "Searchfrm";
            this.Text = "Searchfrm";
            ((System.ComponentModel.ISupportInitialize)(this.dgvSearcContents)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtPatientID_Search;
        private System.Windows.Forms.Button btnEnter;
        private System.Windows.Forms.DataGridView dgvSearcContents;
    }
}
﻿using PitsoOliphant_578437_PRG262_Project;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace PRG262_Project
{
    internal class Verification
    {
        public string NameOfUser { get; set; }  
        public string Password { get; set; }
      

      
    }
}

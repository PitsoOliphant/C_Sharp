﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Windows.Forms;

namespace PitsoOliphant_578437_PRG262_Project
{
    public class Person
    {
        public string Name { get; set; }
        public string  Password { get; set; }
        public Person(string n,string p)
        {
            Name = n;
            Password=p;
        }
        public void verify(string n, string p)
        {
            string path = @"C:\Users\Pitso Oliphant\Desktop\container\UserCredentials.txt";
            string[] txtContents = new string[] { };
            txtContents = File.ReadAllText(path).Split(',');
            string name=txtContents[0];
            string password=txtContents[1];
            Person motho = new Person(name,password);
            //txtContents.ToString();
           // string[] container = new string[] { };
            //for (int i = 0; i < txtContents.Length; i++)
            //{
                //if (i == 0)
                //{
                   // motho.Name = txtContents[0];
                ////}
                //if (i == 1)
                //{
                    //motho.Password = txtContents[1];
            //}
            // }
            //Name= txtContents[0];
            //Password= txtContents[1];
            //for (int i = 0; i < txtContents.Length; i++)
            //{
            //    motho.Name = txtContents[0];
            //    motho.Password = txtContents[1];
            //}
        }

            //return result;


        }
    }


﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;


namespace PitsoOliphant_578437_PRG262_Project
{
    public class NewAccount
    {
       public string UserName { get; set; }
        public string UserPassword { get; set; }
        public NewAccount(string userName, string password)
        {
            UserName = userName;
            UserPassword = password;
        }

        public void register(string u, string p)
        {
            string path = @"C:\Users\Pitso Oliphant\Desktop\container\UserCredentials.txt";

            using (StreamReader reader = new StreamReader(path))
            {
            
                if (reader.Peek() == -1)
                {
                    reader.Close();
                    using (StreamWriter writer = new StreamWriter(path))
                    {
                        writer.WriteLine(u + "," + p);
                    }
                }
            }


            using (StreamReader reader =new StreamReader(path))
            {
                if (reader.Peek() != -1)
                 {
                    reader.Close();
                    using (StreamWriter writer = File.AppendText(path))
                    {
                        writer.WriteLine(u + "," + p);
                    }
                }

            }
        }

    }
}

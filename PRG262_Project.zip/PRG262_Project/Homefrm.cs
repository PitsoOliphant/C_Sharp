﻿using PitsoOliphant_578437_PRG262_Project;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PRG262_Project
{
    public partial class Homefrm : Form
    {
        public Homefrm()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            SignInfrm signinfrm = new SignInfrm();
            signinfrm.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            LogInfrm login = new LogInfrm();
            login.Show();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }
    }
}

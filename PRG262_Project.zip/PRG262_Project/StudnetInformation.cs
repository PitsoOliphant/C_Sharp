﻿using PitsoOliphant_578437_PRG262_Project;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PRG262_Project
{
    public partial class StudnetInformation : Form
    {
        Student NgwanaWaSkolo = new Student();
        DataHandler dl =new DataHandler();
        DataTable tb = new DataTable();
        public StudnetInformation()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            NgwanaWaSkolo.StudentID = int.Parse(textBox3.Text);
            NgwanaWaSkolo.Name = textBox1.Text;
            NgwanaWaSkolo.Surname = textBox2.Text;
            NgwanaWaSkolo.CourseCode = comboBox1.SelectedText;
            NgwanaWaSkolo.DateOfBirth = dateTimePicker1.Value;
            NgwanaWaSkolo.Phone = textBox5.Text;
            NgwanaWaSkolo.Gender = comboBox2.SelectedText;
            NgwanaWaSkolo.StudentImage = pictureBox1.Image;
            NgwanaWaSkolo.Address = textBox6.Text;
            NgwanaWaSkolo.CourseName = textBox4.Text;
            NgwanaWaSkolo.CourseDescription= textBox7.Text;
            //(int Sid, string fn, string sn, Image i, DateTime dob, string g, string p, string a, string cc, string cd, string cn)
            dl.Register(NgwanaWaSkolo.StudentID, NgwanaWaSkolo.Name, NgwanaWaSkolo.Surname, NgwanaWaSkolo.StudentImage, NgwanaWaSkolo.DateOfBirth, NgwanaWaSkolo.Gender, NgwanaWaSkolo.Phone, NgwanaWaSkolo.Address, NgwanaWaSkolo.CourseCode,NgwanaWaSkolo.CourseName,NgwanaWaSkolo.CourseDescription);
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            dataGridView1.DataSource = dl.Display();

        }

        private void button3_Click(object sender, EventArgs e)
        {
            NgwanaWaSkolo.StudentID = int.Parse(textBox3.Text);
            NgwanaWaSkolo.Name = textBox1.Text;
            NgwanaWaSkolo.Surname = textBox2.Text;
            NgwanaWaSkolo.CourseCode = comboBox1.SelectedText;
            NgwanaWaSkolo.DateOfBirth = dateTimePicker1.Value;
            NgwanaWaSkolo.Phone = textBox5.Text;
            NgwanaWaSkolo.Gender = comboBox2.SelectedText;
            NgwanaWaSkolo.StudentImage = pictureBox1.Image;
            NgwanaWaSkolo.Address = textBox6.Text;
            NgwanaWaSkolo.CourseName = textBox4.Text;
            NgwanaWaSkolo.CourseDescription = textBox7.Text;
            dl.Update(NgwanaWaSkolo.StudentID,NgwanaWaSkolo.Name, NgwanaWaSkolo.Surname, NgwanaWaSkolo.StudentImage, NgwanaWaSkolo.DateOfBirth, NgwanaWaSkolo.Gender, NgwanaWaSkolo.Phone, NgwanaWaSkolo.Address, NgwanaWaSkolo.CourseCode,NgwanaWaSkolo.CourseDescription,NgwanaWaSkolo.CourseName);
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Deletefrm dlt = new Deletefrm();
            dlt.Show();
        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void label10_Click(object sender, EventArgs e)
        {

        }

        private void button5_Click(object sender, EventArgs e)
        {
            Searchfrm search = new Searchfrm();
            search.Show();
        }
    }
}

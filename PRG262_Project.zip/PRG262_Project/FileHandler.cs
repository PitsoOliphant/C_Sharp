﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PitsoOliphant_578437_PRG262_Project
{
    public class FileHandler
    {
        public List<string> Reader()
        {
            List<string> TextFileInfor = new List<string>();
            TextFileInfor=File.ReadAllLines(@"C:\Users\Pitso Oliphant\Desktop\container\UserCredentials.txt").ToList();
            foreach (var item in TextFileInfor)
            {
                Console.WriteLine(item);
            }
            return TextFileInfor;   
        }

       //public List<string> verification(List<string>data)
       // //{
       // //    string path= @"C:\Users\Pitso Oliphant\Desktop\container\UserCredentials.txt";

        //    //info=Reader();

        //    List<string>TextInfor= new List<string>();  
        //    TextInfor=File.ReadAllLines(path).ToList();
        //    string[] infor = new string[] { };
        //    foreach (var item in data)
        //    {
        //        infor = item.Split(',');
        //        Person profile = new Person(infor[0], infor[1]);
        //        TextInfor.Add(profile.ToString());
        //    }
        //    return TextInfor;

            
            
            
            
        //}

    }
}

﻿using PRG262_Project;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PitsoOliphant_578437_PRG262_Project
{
    public partial class LogInfrm : Form
    {
       // string path=@""
        DataHandler handler =new DataHandler();
        FileHandler fl =new FileHandler();
        Verification v = new Verification();
       // Person p = new Person();

        public LogInfrm()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Person motho =new Person(textBox1.Text,textBox2.Text);
            if (textBox1.Text == motho.Name && textBox2.Text == motho.Password)
            {
                MessageBox.Show("Welcome!");
                
                StudnetInformation stfrm = new StudnetInformation();
                stfrm.Show();


            }
            else
            {
                MessageBox.Show("Invalid");
            }
                motho.verify(textBox1.Text,textBox2.Text);
           
            
            //if (textBox1.Text==fl.verification().ToString()&&textBox2.Text==fl.verification().ToString())
            //{
            //    MessageBox.Show("Welcome!");
            //}
            //else
            //{
            //    MessageBox.Show("invalid!");
            //}
        }
    }
}

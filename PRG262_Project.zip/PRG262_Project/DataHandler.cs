﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PitsoOliphant_578437_PRG262_Project
{
    public class DataHandler
    {
        public List<string> CredentialsReader(List<string> data)
        {
            List<Person> people = new List<Person>();
            string[] items = new string[] { };
            foreach (var item in data)
            {
                items = item.Split(',');
                //Person student = new Person("","");
                //people.Add(student);

            }
            //
            List<string> StringData = new List<string>();
            foreach (var item in people)
            { 
                Console.WriteLine(item);
                StringData.Add(item.ToString());
            }

            return StringData;
        }
        string connection = @"Data Source=DESKTOP-MOU8UR7\SQLEXPRESS; Initial Catalog=PRG_PROJECT; Integrated Security=True";
        SqlConnection con;
        SqlDataAdapter adapter;
        SqlCommand comm;

        public void Register(int Sid,string fn ,string sn,Image i,DateTime dob,string g,string p,string a,string cc,string cd,string cn)
        {
            string query = $"INSERT INTO BelgiumcampusStudent VALUES('{Sid}','{fn}','{sn}','{i}','{dob}','{g}','{p}','{a}','{cc}','{cd}','{cn}')";
            con=new SqlConnection(connection);
            con.Open();
            comm=new SqlCommand(query,con);
            try
            {
                comm.ExecuteNonQuery();
                MessageBox.Show("Details saved!");
            }
            catch (Exception e)
            {
                MessageBox.Show("Details not saved!" + e.Message);
                throw;
            }

        }
       


        public DataTable Display()
        {
            string query = @"SELECT * FROM BelgiumcampusStudent";
            con = new SqlConnection(connection);
            comm=new SqlCommand (query,con);
            adapter = new SqlDataAdapter(query, con);
            DataTable tb =new DataTable();
            adapter.Fill(tb);
            return tb;

        }
        public void Update(int Sid, string fn, string sn, Image i, DateTime dob, string g, string p, string a, string cc, string cd, string cn)
        {
            string query = $"UPDATE BelgiumcampusStudent SET [StudentID]='{Sid}' , [StudentSurname]='{sn}',[StudentImage]='{i}', [DateofBirth]='{dob}',[Gender]='{g}',[Phone]='{p}',[Address]='{a}',[CourseCode]='{cc}',[CoursDescription]='{cd}',[CourseName]='{cn}' WHERE [StudentID]='{Sid}'";


            con =new SqlConnection (connection);
            comm=new SqlCommand(query,con); 
            adapter=new SqlDataAdapter(query,con);
                con.Open();
            try
            {
                comm.BeginExecuteNonQuery();
                MessageBox.Show("Details updated!");
            }
            catch (Exception ea)
            {
                MessageBox.Show("falied to update: " + ea.Message);
               
            }

        }
        public void Delete(int Sid)
        {
            string query = $"DELETE FROM BelgiumcampusStudent WHERE StudentID='{Sid}'";
            con=new SqlConnection (connection);
            comm = new SqlCommand(query, con);
            con.Open();
            try
            {
                comm.BeginExecuteNonQuery();
                MessageBox.Show("Datails Deleted");
            }
            catch (Exception ex)
            {

                MessageBox.Show("Could not delete: "+ex.Message);
            }
        }
        public DataTable Search(int sid)
        {
            string query = $"SELECT * FROM BelgiumcampusStudent WHERE [StudentID]='{sid}' ";
            con=new SqlConnection (connection); 
            comm =new SqlCommand(query, con);
            adapter= new SqlDataAdapter(query,con); 
            DataTable tlb = new DataTable();
            adapter.Fill(tlb);
            return tlb;
        }









    }
}

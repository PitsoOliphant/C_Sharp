﻿using PitsoOliphant_578437_PRG262_Project;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PRG262_Project
{
    public partial class Deletefrm : Form
    { Student NgwanaWaSkolo =new Student();
        DataHandler dh = new DataHandler();
        public Deletefrm()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
         dh.Delete(NgwanaWaSkolo.StudentID);
            
        }
    }
}
